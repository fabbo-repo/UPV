 void write_log_2 ( 
	char *senyal,
	dword pc_read,
	dword pc_write,
	char *fase_read,
	char *fase_write
	 );
 void write_log_1 ( 
	char *senyal,
	dword pc,
	unsigned char reg
	 );
 void write_log ( 
	char *senyal,
	dword pc
	 );
