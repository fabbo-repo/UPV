 void fase_EX_1 (void);
 boolean fase_EX_1_ENTEROS ( 
	unsigned int oper
	 );
 boolean fase_EX_1_SUMREST ( 
	unsigned int oper
	 );
 boolean fase_EX_1_MULTDIV ( 
	unsigned int oper
	 );
 boolean fase_EX_1_DIRECCIONES ( 
	unsigned int oper
	 );
 boolean fase_EX_1_MEMDATOS ( 
	unsigned int oper
	 );
 void fase_EX_2 (void);
 void fase_EX_2_ENTEROS ( 
	unsigned int oper
	 );
 void fase_EX_2_SUMREST ( 
	unsigned int oper
	 );
 void fase_EX_2_MULTDIV ( 
	unsigned int oper
	 );
 void fase_EX_2_DIRECCIONES ( 
	unsigned int oper
	 );
 void fase_EX_2_MEMDATOS ( 
	unsigned int oper
	 );
