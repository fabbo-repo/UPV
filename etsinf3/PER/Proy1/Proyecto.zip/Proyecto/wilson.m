# X es el conjunto de prototipos
# xl es el vector de etiquetas de dichos prototipos
# k es el número de vecinos más cercanos a almacenar (= m en mnn(...))
function [V,ind] = wilson(X,xl,k)
  # Se inicializa a los números naturales de 1 a N
  ind = [1:rows(X)];
  # V es el vector que contiene los índices de los k-NN de cada prototipo en X
  V = mnn(X,xl,min(100,rows(X)-1)); # consideramos almacenar hasta 100-NN
  
  error=true;
  while(error)
    error=false;
   for i=1:rows(X)
     printf("ok\n")
     # Clasificar el prototipo i
     c = knnV(V(:,i),ind,xl,k);
     printf("%d\n",c);
     if(c != xl(i))
      printf("estoy dentro\n");
      ind = setdiff(ind,i); #error = true;
     endif
   endfor
  endwhile
endfunction
