function[m,Xm,covar,sortedLambda,sortedVecP,W] = pca(X,D)
  # Calculamos el vector media por filas
  m = mean(X)';
  # Restar a todos los datos el vector media
  Xm = X - m';
  # Calcular matriz de covarianza
  covar = Xm'*Xm/rows(X);
  # Calcular los vectores y valores propios: VecP --> vectores propios y lambda--> valores propios
  [VecP, lambda] = eig(covar);
  # Ordenar los vectores propios segun su valor propio de forma descendente
  [sortedLambda,indices] = sort(diag(lambda), "descend"); # diag me permite obtener el vector diagonal para ordenar
  # Todos los vectores propios, ordenados, por columnas
  sortedVecP = VecP(:,indices);
  # Matriz de proyecci�n en la dimensi�n D
  W = sortedVecP(:,1:D);
endfunction

# Entrada: 
  # X por filas
  # Dimensi�n D
# Salida: 
  # m por columnas
  # Xm por filas
  # Matriz de covarianza
  # sortedLambda: valores propios de la MCovarianza
  # sortedVecP por columnas
  # W por columnas