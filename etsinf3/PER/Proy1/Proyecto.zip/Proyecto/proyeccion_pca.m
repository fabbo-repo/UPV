function[Xp] = proyeccion_pca(Xm,W)
  # De los vectores propios ordenados, coger los D primeros: matriz de proyecci�n W
  #W = W(:,1:D);
  # Los datos proyectados Xp: matriz de proyecci�n por datos normalizados
  # Los vectores propios van por filas y los datos normalizados por columnas
  Xp = W'*Xm';
endfunction

# Entrada: 
  # Xm por filas
  # W por columnas
# Salida:
  # Datos proyectados: Xp por columnas