# CRI
Practicas de Criptografia de la UPV  del año 2018-2019

- incompletas de Criptografia y criptogramas.
- Trabajo monografico sobre la seguridad en tarjetas de credito (Banda magnetica y Microchips)
