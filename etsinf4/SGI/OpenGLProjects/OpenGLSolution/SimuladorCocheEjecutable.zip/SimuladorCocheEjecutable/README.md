# Características:

* Pista fija

* Al pasar por debajo de la meta se incrementa un punto.

* Los puntos aparecen en la zona inferior derecha de la pantalla.

* La velocidad incrementa con la pulsación de la tecla UP, al soltar dicha tecla la velocidad decrementa.

* Si la velocidad está a 0 se puede ir hacia atrás con la tecla DOWN.

* Solo se puede girar el coche si la velocidad es distinta de 0.

* En la zona central a la derecha del volante aparece un indicador de velocidad.

* Hay sonidos al pulsar y soltar la tecla UP, se pueden desactivar con 'm' o 'M'.

* Una de las texturas del suelo es de menor tamaño en comparación a la otra con varias líneas para tener mejor efecto de iluminación y se va actualizando de posición a medida que el coche se mueve, por eficiencia.