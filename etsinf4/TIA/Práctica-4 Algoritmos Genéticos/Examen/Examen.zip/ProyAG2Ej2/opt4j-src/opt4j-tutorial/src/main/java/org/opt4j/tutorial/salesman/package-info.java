 

/**
 * The salesman example implements the <a
 * href="http://en.wikipedia.org/wiki/Traveling_salesman_problem">Traveling
 * Salesman Problem</a>. A problem-specific GUI is added.
 */
package org.opt4j.tutorial.salesman;

