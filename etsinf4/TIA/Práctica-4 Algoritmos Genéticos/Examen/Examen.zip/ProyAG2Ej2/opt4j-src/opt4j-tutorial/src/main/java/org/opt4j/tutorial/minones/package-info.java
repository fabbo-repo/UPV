 

/**
 * The minones example is a simple problem which uses SAT decoding to hand
 * infeasible individuals.
 */
package org.opt4j.tutorial.minones;

