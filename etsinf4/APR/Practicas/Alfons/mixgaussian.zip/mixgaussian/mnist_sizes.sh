#!/usr/bin/octave
load("train-images-idx3-ubyte.mat.gz"); size(X)
load("train-labels-idx1-ubyte.mat.gz"); size(xl)
load("t10k-images-idx3-ubyte.mat.gz");  size(Y)
load("t10k-labels-idx1-ubyte.mat.gz");  size(yl)
