#!/bin/bash
ltrace setarch x86_64 -R ./echo 8080

