#!/bin/bash
setarch x86_64 -R ltrace ./vuln
