#include <stdio.h>

void primera(int x, int y, int x1, int x2){ 
	printf("En primera\n"); 
}

int main(int argc, char *argv[]){
    primera(1,2,3,4);
}
