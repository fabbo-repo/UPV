#include <stdio.h>

int main(int argc, char *argv[]){
	int contador = 0;
	int array[10];
	while ( contador < 10 ) {
		array[contador] = 20;
		contador ++;
	}
}
