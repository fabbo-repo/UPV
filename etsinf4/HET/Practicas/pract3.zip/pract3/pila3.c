#include <stdio.h>

int main(int argc, char *argv[]){
	int contador = 0;
	while ( contador < 10 ) contador ++;
}
