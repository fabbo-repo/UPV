
int cuadrado(int x) {
	return x*x;
}

void main() {
	cuadrado(3);
}
