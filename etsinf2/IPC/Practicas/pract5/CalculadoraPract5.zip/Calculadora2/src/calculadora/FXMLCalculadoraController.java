 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadora;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author Fabianno
 */
public class FXMLCalculadoraController implements Initializable {

    @FXML
    private TextField casillaCalculo;
    @FXML
    private Button boton7;
    @FXML
    private Button botonC;
    @FXML
    private Button boton8;
    @FXML
    private Button boton9;
    @FXML
    private Button boton4;
    @FXML
    private Button boton5;
    @FXML
    private Button boton6;
    @FXML
    private Button boton1;
    @FXML
    private Button boton2;
    @FXML
    private Button boton3;
    @FXML
    private Button boton0;
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void pulsarC(ActionEvent event) {
        casillaCalculo.setText("0");
    }

    private void pulsarComa(ActionEvent event) {
        if(casillaCalculo.getText().indexOf('.')==-1)
            casillaCalculo.setText(casillaCalculo.getText()+".");
    }
    
    @FXML
    private void pulsar7(ActionEvent event) {
        if(casillaCalculo.getText().equals("0"))casillaCalculo.setText("");
        casillaCalculo.setText(casillaCalculo.getText()+"7");
    }

    @FXML
    private void pulsar8(ActionEvent event) {
        if(casillaCalculo.getText().equals("0"))casillaCalculo.setText("");
        casillaCalculo.setText(casillaCalculo.getText()+"8");
    }

    @FXML
    private void pulsar9(ActionEvent event) {
        if(casillaCalculo.getText().equals("0"))casillaCalculo.setText("");
        casillaCalculo.setText(casillaCalculo.getText()+"9");
    }

    @FXML
    private void pulsar4(ActionEvent event) {
        if(casillaCalculo.getText().equals("0"))casillaCalculo.setText("");
        casillaCalculo.setText(casillaCalculo.getText()+"4");
    }

    @FXML
    private void pulsar5(ActionEvent event) {
        if(casillaCalculo.getText().equals("0"))casillaCalculo.setText("");
        casillaCalculo.setText(casillaCalculo.getText()+"5");
    }

    @FXML
    private void pulsar6(ActionEvent event) {
        if(casillaCalculo.getText().equals("0"))casillaCalculo.setText("");
        casillaCalculo.setText(casillaCalculo.getText()+"6");
    }

    @FXML
    private void pulsar1(ActionEvent event) {
        if(casillaCalculo.getText().equals("0"))casillaCalculo.setText("");
        casillaCalculo.setText(casillaCalculo.getText()+"1");
    }

    @FXML
    private void pulsar2(ActionEvent event) {
        if(casillaCalculo.getText().equals("0"))casillaCalculo.setText("");
        casillaCalculo.setText(casillaCalculo.getText()+"2");
    }

    @FXML
    private void pulsar3(ActionEvent event) {
        if(casillaCalculo.getText().equals("0"))casillaCalculo.setText("");
        casillaCalculo.setText(casillaCalculo.getText()+"3");
    }

    @FXML
    private void pulsar0(ActionEvent event) {
        if(!casillaCalculo.getText().equals("0"))
            casillaCalculo.setText(casillaCalculo.getText()+"0");
    }
    
}
