/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package relojdigital;

import java.net.URL;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import javafx.beans.binding.Bindings;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

/**
 *
 * @author Fabianno
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label label;
    
    private Reloj time;
    @FXML
    private Button mostrarBoton;
    @FXML
    private Button pararBoton;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        this.time = new Reloj();
        this.pararBoton.setDisable(true);
        
    }    

    @FXML
    private void mostrarHandler(ActionEvent event) {
        if(this.time.isCancelled()||!this.time.isRunning()){
            this.time = new Reloj();
            this.label.textProperty().bind(Bindings.convert(this.time.valueProperty()));
            Thread myThread = new Thread(this.time);
            myThread = new Thread(time);
            myThread.setDaemon(true);
            myThread.start();
        }
        this.pararBoton.setDisable(false);
        this.mostrarBoton.setDisable(true);
    }

    @FXML
    private void pararHandler(ActionEvent event) {
        if(this.time.isRunning())
            this.time.cancel();
        
        this.pararBoton.setDisable(true);
        this.mostrarBoton.setDisable(false);
    }
    
    class Reloj extends Task<String>{
        @Override
        protected String call() throws Exception {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
            while(!isCancelled()){
                updateValue(LocalTime.now().format(formatter));
            }
            return "";
        }
        
    }
}
