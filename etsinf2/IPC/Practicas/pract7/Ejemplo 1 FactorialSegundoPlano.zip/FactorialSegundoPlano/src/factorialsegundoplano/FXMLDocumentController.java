/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package factorialsegundoplano;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;

/**
 *
 * @author jsanchez
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private TextField numero;
    @FXML
    private TextField resultado;
    
    private Factorial miTarea;
    @FXML
    private ProgressBar barraProgreso;
    @FXML
    private Button BotonCalcular;
    @FXML
    private Button BotonCancelar;

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
      
        numero.addEventFilter(KeyEvent.KEY_TYPED, new EventHandler<KeyEvent>() {
            @Override public void handle(KeyEvent keyEvent) {
            if (!"0123456789".contains(keyEvent.getCharacter())) {
                            keyEvent.consume(); }
            }
            });
        
         BotonCalcular.disableProperty().bind(numero.textProperty().isEmpty()); 
         BotonCancelar.setDisable(true);
         resultado.setVisible(false);
    }    

    @FXML
    private void bCalcular(ActionEvent event) {
        
    Long factorial;
    factorial = Long.parseLong(this.numero.getText()); 
    miTarea = new Factorial(factorial);       
    resultado.textProperty().bind(Bindings.convert(miTarea.valueProperty()));
    barraProgreso.progressProperty().bind(miTarea.progressProperty());
    resultado.visibleProperty().bind(Bindings.not(miTarea.runningProperty())); 
    // texto resultado deshabilitado
    BotonCalcular.disableProperty().bind(miTarea.runningProperty()); 
    
    miTarea.setOnSucceeded(new EventHandler<WorkerStateEvent>() {
        @Override
        public void handle(WorkerStateEvent event) {
        BotonCancelar.setDisable(true);
        }
     });

    
    
    BotonCancelar.setDisable(false);
    Thread th = new Thread(miTarea);
    th.setDaemon(true);
    th.start();
    
    
        
    }

    @FXML
    private void bCancelar(ActionEvent event) {
        miTarea.cancel();
    }

    @FXML
    private void bSalir(ActionEvent event) {
        Platform.exit();
    }
    
}
