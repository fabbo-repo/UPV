/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progressexample;

import java.net.URL;
import java.time.Duration;
import java.time.LocalTime;
import java.util.ResourceBundle;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressIndicator;

/**
 *
 * @author DSIC_jsoler
 */
public class FXMLProgressController implements Initializable {
    
  
    @FXML
    private ProgressIndicator progressIndicator;
    @FXML
    private Button button;
    @FXML
    private Label info;
    
    class MyTask extends Task<Void>{

        @Override
        protected Void call() throws Exception {
            LocalTime initTime= LocalTime.now();
            LocalTime lastTime =initTime.plusSeconds(5);
            System.out.println(lastTime.getSecond());
            Duration interval= Duration.ofSeconds(5);
            do {
                Thread.sleep(100);
                updateProgress(Duration.between(initTime,LocalTime.now()).toMillis() , interval.toMillis());

            }while(lastTime.isAfter(LocalTime.now()));
            return null;
        }
        
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void wait5Seconds(ActionEvent event) {
        info.setText("");
        button.setDisable(true);
        //-------------------------------------------------
        // hay que volver a crear la task cada vez
        MyTask spentTime = new MyTask();
        Thread myThread = new Thread(spentTime);
        myThread.setDaemon(true);

        progressIndicator.progressProperty().bind(spentTime.progressProperty());
        spentTime.setOnSucceeded(e -> {
            info.setText("5 seconds ");
            button.setDisable(false);

        });
        myThread.start();
    }

}
