/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;

/**
 * FXML Controller class
 *
 * @author Fabianno
 */
public class VistaPrincipalController implements Initializable {

    @FXML
    private Button barButton;
    @FXML
    private Button lineButton;
    @FXML
    private PieChart pieChart;
    @FXML
    private BarChart<String, Number> barChart;
    @FXML
    private LineChart<String, Number> lineChart;
    
    private ObservableList<PieChart.Data> pieData;

    private ObservableList<XYChart.Data<String,Number>> dataBar;
        
    private ObservableList<XYChart.Data<String,Number>> dataLine;
    @FXML
    private GridPane pane;
    
    private boolean dark;
        
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        this.dark = false;
        
        pane.getStylesheets().add(
                this.getClass().getResource("/css/estilodefault.css").toExternalForm());
        
        this.barButton.setDisable(true);
        
        pieData = FXCollections.observableArrayList(new PieChart.Data("Suspenso", 0),
                new PieChart.Data("Aprobado", 0),new PieChart.Data("Bien", 0),
                new PieChart.Data("Notable", 0),new PieChart.Data("Sobresaliente", 0));
        
        dataBar = FXCollections.observableArrayList(new XYChart.Data("Suspenso", 0),
                new XYChart.Data("Aprobado", 0),new XYChart.Data("Bien", 0),
                new XYChart.Data("Notable", 0),new XYChart.Data("Sobresaliente", 0));
        XYChart.Series serieBar = new XYChart.Series(dataBar);
        serieBar.setName("Alumnos con cada nota");
        barChart.getData().add(serieBar);
        
        dataLine = FXCollections.observableArrayList(new XYChart.Data("Suspenso", 0),
                new XYChart.Data("Aprobado", 0),new XYChart.Data("Bien", 0),
                new XYChart.Data("Notable", 0),new XYChart.Data("Sobresaliente", 0));
        XYChart.Series serieLine = new XYChart.Series(dataLine);
        serieLine.setName("Alumnos con cada nota");
        lineChart.getData().add(serieLine);

        pieChart.setData(pieData);
        pieChart.setTitle("Notas IPC");
    }    

    @FXML
    private void barHandler(ActionEvent event) {
        this.barChart.setVisible(true);
        this.lineChart.setVisible(false);
        this.barButton.setDisable(true);
        this.lineButton.setDisable(false);
    }

    @FXML
    private void lineHandler(ActionEvent event) {
        this.barChart.setVisible(false);
        this.lineChart.setVisible(true);
        this.lineButton.setDisable(true);
        this.barButton.setDisable(false);
    }

    @FXML
    private synchronized void changeModeHandler(ActionEvent event) {
        if(dark){
            pane.getStylesheets().remove(0);
            pane.getStylesheets().add(
                    this.getClass().getResource("/css/estilodefault.css").toExternalForm());
            dark=false;
        }
        else{
            pane.getStylesheets().remove(0);
            pane.getStylesheets().add(
                    this.getClass().getResource("/css/estilodark.css").toExternalForm());
            dark=true;
        }
    }

    @FXML
    private void suspensoHandler(ActionEvent event) {
        this.pieData.get(0).setPieValue(this.pieData.get(0).getPieValue()+1);
        this.dataBar.get(0).setYValue(this.dataBar.get(0).getYValue().intValue()+1);
        this.dataLine.get(0).setYValue(this.dataLine.get(0).getYValue().intValue()+1);
    }

    @FXML
    private void aprobadoHandler(ActionEvent event) {
        this.pieData.get(1).setPieValue(this.pieData.get(1).getPieValue()+1);
        this.dataBar.get(1).setYValue(this.dataBar.get(1).getYValue().intValue()+1);
        this.dataLine.get(1).setYValue(this.dataLine.get(1).getYValue().intValue()+1);
    }

    @FXML
    private void bienHandler(ActionEvent event) {
        this.pieData.get(2).setPieValue(this.pieData.get(2).getPieValue()+1);
        this.dataBar.get(2).setYValue(this.dataBar.get(2).getYValue().intValue()+1);
        this.dataLine.get(2).setYValue(this.dataLine.get(2).getYValue().intValue()+1);
    }

    @FXML
    private void notableHandler(ActionEvent event) {
        this.pieData.get(3).setPieValue(this.pieData.get(3).getPieValue()+1);
        this.dataBar.get(3).setYValue(this.dataBar.get(3).getYValue().intValue()+1);
        this.dataLine.get(3).setYValue(this.dataLine.get(3).getYValue().intValue()+1);
    }

    @FXML
    private void SobresalienteHandler(ActionEvent event) {
        this.pieData.get(4).setPieValue(this.pieData.get(4).getPieValue()+1);
        this.dataBar.get(4).setYValue(this.dataBar.get(4).getYValue().intValue()+1);
        this.dataLine.get(4).setYValue(this.dataLine.get(4).getYValue().intValue()+1);
    }
    
}
